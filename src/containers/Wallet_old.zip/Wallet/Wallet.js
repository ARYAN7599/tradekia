import React from 'react';
import { useNavigate } from "react-router-dom";
import DollarSvg from "../../assets/images/totalBalance.svg";
import SwapHorizontalCircleIcon from '@material-ui/icons/SwapHorizontalCircle';
import SwapVerticalCircleIcon from '@material-ui/icons/SwapVerticalCircle';
import { DataGrid } from "@material-ui/data-grid";
import Loader from "../../components/Loader/Loader";
import { Switch } from 'pretty-checkbox-react';
import '@djthoms/pretty-checkbox';
import Box from '@mui/material/Box';
import "./SCSS/Wallet.css";
import { connect } from 'react-redux';
import { URL } from "../../helpers/global";
import axios from 'axios';
import Swal from 'sweetalert2';
import { actions } from 'react-table/dist/react-table.development';
import dIcone from '../../assets/images/arrow_down.png';

const Wallet = (props) => {
    const [ischecked,setIschecked]=React.useState(true);
    const [refCount,setRefCount]=React.useState(true);
    const[toTalWalet,setToTalWalet]=React.useState(); 
    const [symble,setSymble]=React.useState([]);
    const [rowData,setRowData]=React.useState([]); 
    const navigate = useNavigate();

    const getUserInfo = async () => {
        try {
            let data = JSON.stringify({
                "userId": `${props.userId}`,
            });

            let config = {
                method: 'post',
                url: `${URL}getOrderData`,
                headers: { 
                    'Content-Type': 'application/json'
                  },
                  data: data
            };
            await axios(config)
                .then(function (res) {
                    setToTalWalet(res?.data?.walletAmount);
                    if (res?.data?.data?.length > 0) {
                        // setRefCount(res.data.data[0].totalReward);
                        setRowData(res?.data?.data); 
                    } 
                })
                .catch(function (error) {
                    console.log(error);
                });
        } catch (err) {
            console.log(err);
        }
    };
React.useEffect(()=>{
    getUserInfo(); 
    setSymble(props.symbleP);
},[]); 

const depositHamdiler=()=>{
    console.log("dipositHandiler"); 
    navigate('/deposit');
}

const WithdrawHamdiler=()=>{
    navigate('/withdraw');
}
const tradeHamdiler=()=>{
    navigate('/trade');
}

    const columns = [
        { field: "coin", headerName: "Coin", minWidth: 120, flex: 0.3 },

        {
            field: "totalBalance",
            headerName: "Total Balance",
            minWidth: 60,
            type: "number",
            flex: 0.3,
            alignItems:'center'
        },
        {
            field: "availableBalance",
            headerName: "Available Balance",
            type: "number",
            minWidth: 60,
            flex: 0.3,
            alignItems:'center'
        },

        {
            field: "lockedBalance",
            headerName: "Locked Balance",
            type: "number",
            minWidth: 60,
            flex: 0.3,
            alignItems:'center'
        },

        {
            field: "btcValue",
            flex: 0.3,
            headerName: "BTC Value",
            minWidth: 60,
            type: "number",
            alignItems:'center'
            // sortable: false,
            // renderCell: (params) => {
            //     return (
            //         <>
            //         <span><h1>{params.btcValue}</h1></span>
                        
            //         </>
            //     );
            // },
        },{
            field: "refralBalance",
            headerName: "Refral Balance",
            type: "number",
            minWidth: 100,
            flex: 0.3,
           
        },

        {
            field: "action",
            headerName: "Action",
            type: "number",
            minWidth: 150,
            flex: 0.5,
            renderCell: (params) => {
                return (
                    <Box sx={{
                        display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                        width: "100%"
                    }}>
                    <span style={{color:'#29e70c'}} onClick={depositHamdiler}><SwapVerticalCircleIcon style={{fontSize:"small",color:"#29e70c"}}/>Deposit</span>
                    <span style={{color:'#be3232'}} onClick={WithdrawHamdiler}><SwapVerticalCircleIcon style={{fontSize:"small",color:"#be3232"}}/>Withdraw</span>
                    <span onClick={tradeHamdiler}><SwapHorizontalCircleIcon style={{fontSize:"small",color:"slategrey"}}/>Trade</span>
                    </Box>
                );
            },
        },
    ];
    if (rowData.length < 1) {
        console.log("hhhd",rowData)
        return <Loader />;
    }
    console.log("hello",toTalWalet); 
    // const rows = [];
    
     

    return (
        <div className='wallet'>
            <h1 className="balance">
                Balance
            </h1>

            <div className='balanceSheet'>
                <div className="balanceSheet_div">
                    <div className='balanceSheet_header'>
                        <div className='totalBal_div'>
                        <img src={DollarSvg} alt="totalBalance" />

                        <div className="balDetails_div">
                            <p>Total balance</p>
                            <h4><span>$</span> {toTalWalet} USD </h4>
                            <p>0.000034221 <span>BTC</span></p>
                        </div>
                        </div>

                        <div className="withDrawLimit_div">
                            <p><span>24h</span>Withdrawal Limit:</p>
                            <p> <span>2</span>BTC</p>
                        </div>

                        <div className="zeroBalanceWallet_div">
                            <Switch onChange={()=>setIschecked(!ischecked)}  shape="fill" color="warning" checked={ischecked}></Switch>
                            <p>Show zero balance wallets</p>
                        </div>
                    </div>
                    <DataGrid
                        rows={rowData}
                        columns={columns}
                        pageSize={5}
                        disableSelectionOnClick
                        className="productListTable"
                        autoHeight
                        autoPageSize="true"
                    />
                </div>
            </div>

        </div>
    )
}

const mapStateToProps = (state) => {
    return ({
        id: state.id,
        userId:state.user_id,
        token: state.token,
        email: state.email,
        symbleP: state.payerSymble,
        
    });
}

export default connect(mapStateToProps)(Wallet);