import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Hidden from '@material-ui/core/Hidden';
import withWidth from '@material-ui/core/withWidth';
import Typography from '@material-ui/core/Typography';
import DollarSvg from "../../assets/images/totalBalance.svg";
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import TradingViewWidget, { Themes } from 'react-tradingview-widget';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import IconButton from '@mui/material/IconButton';
import Input from '@mui/material/Input';
import FilledInput from '@mui/material/FilledInput';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Button from '@mui/material/Button';
import { padding } from '@mui/system';
// import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import './TradChart.css';
//chield Component
import Torders from './TChild/Torders';
import Tordergreen from './TChild/Tordergreen';
import Tpairs from './TChild/Tpairs';
import Thistory from './TChild/Thistory';

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
        flex: '1 0 auto',
        margin: theme.spacing(1),
    },
}));
const columns = [
    {
        id: 'price',
        label: 'Price',
        minWidth: 60,
        align: 'right',
        format: (value) => value.toLocaleString('en-US'),
    },
    {
        id: 'amount',
        label: 'Amount',
        minWidth: 60,
        align: 'right',
        format: (value) => value.toLocaleString('en-US'),
    },
    {
        id: 'total',
        label: 'Total',
        minWidth: 60,
        align: 'right',
        format: (value) => value.toFixed(2),
    },
];
function createData(price, amount) {
    const total = price + amount;
    return { price, amount, total };
}
const rows = [
    createData(1324171354, 3287263),
    createData(1403500365, 9596961),
    createData(60483973, 301340),
    createData(327167434, 9833520),
    createData(37602103, 9984670),
    createData(25475400, 7692024),
    createData(83019200, 357578),
    createData(4857000, 70273),
    createData(126577691, 1972550),
    createData(126317000, 377973),
    createData(67022000, 640679),
    createData(67545757, 242495),
    createData(146793744, 17098246),
    createData(200962417, 923768),
    createData(210147125, 8515767),
];
function TradChart(props) {
    const [values, setValues] = React.useState({
        amount: '',
        password: '',
        weight: '',
        weightRange: '',
        showPassword: false,
    });

    //   const handleChange = (prop) => (event) => {
    //     setValues({ ...values, [prop]: event.target.value });
    //   };

    const handleClickShowPassword = () => {
        setValues({
            ...values,
            showPassword: !values.showPassword,
        });
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    const classes = useStyles();
    const { width } = props;

    return (
        <Box sx={{
            background: "#e0e0e0"
        }}>
            <div id="tradehead" >
                <div className={classes.container}>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className='balanceSheet_header'>
                                <div className='totalBal_div'>
                                    {/* <img src={DollarSvg} alt="totalBalance" /> */}
                                    <span>Bitcoin</span>
                                    <div className="balDetails_div">
                                        <h4>BTC-USDT</h4>

                                    </div>
                                </div>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className="balDetails_div">
                                <span>Last Price</span>
                                <h4> 12341.34</h4>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className="balDetails_div">
                                <span>24h Change</span>
                                <h4>1.65 (0%)</h4>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className="balDetails_div">
                                <span>24h High</span>
                                <h4>12341.34</h4>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden smDown>
                        <Paper className={classes.paper}> <div className="balDetails_div">
                            <span>24h Low</span>
                            <h4>12341.34</h4>
                        </div></Paper>
                    </Hidden>
                    <Hidden mdDown>
                        <Paper className={classes.paper}><div className="balDetails_div">
                            <span>BTC</span>
                            <h4>1234145325.34 USD </h4>
                        </div></Paper>
                    </Hidden>

                </div>
            </div>

            <div className={classes.root}>
                <div className={classes.container}>
                    <Hidden xsDown>
                        <Box>
                            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                                <TableContainer sx={{ maxHeight: 440 }}>
                                    Orders Books
                                    <Table stickyHeader aria-label="sticky table">
                                        <TableHead>

                                            <TableRow>
                                                {columns.map((column) => (
                                                    <TableCell id="tablecell"
                                                        key={column.id}
                                                        align={column.align}
                                                        style={{ minWidth: column.minWidth }}
                                                    >
                                                        {column.label}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {rows
                                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                                .map((row) => {
                                                    return (
                                                        <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                                            {columns.map((column) => {
                                                                const value = row[column.id];
                                                                return (
                                                                    <TableCell id="tablecell" key={column.id} align={column.align}>
                                                                        {column.format && typeof value === 'number'
                                                                            ? column.format(value)
                                                                            : value}
                                                                    </TableCell>
                                                                );
                                                            })}
                                                        </TableRow>
                                                    );
                                                })}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                                {/* <TablePagination
                                    rowsPerPageOptions={[10, 25, 100]}
                                    component="div"
                                    count={rows.length}
                                    rowsPerPage={rowsPerPage}
                                    page={page}
                                    onPageChange={handleChangePage}
                                    onRowsPerPageChange={handleChangeRowsPerPage}
                                /> */}
                            </Paper>
                            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                                <TableContainer sx={{ maxHeight: 440 }}>
                                    <Table stickyHeader aria-label="sticky table">
                                        <TableHead>
                                            <TableRow>
                                                {columns.map((column) => (
                                                    <TableCell id="tablecell"
                                                        key={column.id}
                                                        align={column.align}
                                                        style={{ minWidth: column.minWidth }}
                                                    >
                                                        {column.label}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {rows
                                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                                .map((row) => {
                                                    return (
                                                        <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                                            {columns.map((column) => {
                                                                const value = row[column.id];
                                                                return (
                                                                    <TableCell id="tablecell" key={column.id} align={column.align}>
                                                                        {column.format && typeof value === 'number'
                                                                            ? column.format(value)
                                                                            : value}
                                                                    </TableCell>
                                                                );
                                                            })}
                                                        </TableRow>
                                                    );
                                                })}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                                {/* <TablePagination
                                    rowsPerPageOptions={[10, 25, 100]}
                                    component="div"
                                    count={rows.length}
                                    rowsPerPage={rowsPerPage}
                                    page={page}
                                    onPageChange={handleChangePage}
                                    onRowsPerPageChange={handleChangeRowsPerPage}
                                /> */}
                            </Paper>
                        </Box>
                    </Hidden>
                    <Hidden xsDown>
                        <Box id="chartview">
                            <Paper sx={{ width: '100%', overflow: 'hidden', padding: '0px 5px', margin: '0px 5px' }}>
                                <div id="tradingview_ea09b"></div>
                                <TradingViewWidget
                                    // symbol="NASDAQ:AAPL"
                                    // theme={Themes.DARK}
                                    // locale="fr"
                                    // autosize
                                    width="100%"
                                    height="350px"
                                    symbol="NASDAQ:AAPL"
                                    interval="D"
                                    timezone="Etc/UTC"
                                    // theme="dark"
                                    // style="1"
                                    locale="en"
                                    toolbar_bg="#f1f3f6"
                                    enable_publishing="false"
                                    allow_symbol_change="true"
                                    container_id="tradingview_ea09b"
                                />
                            </Paper>
                            <Paper id="tradForm" className={classes.paper}>
                                <Box >
                                    <TabContext sx={{ bottom: '10px' }} value={value}>
                                        <Box sx={{ borderBottom: 1, height: "35px", borderColor: 'divider', bottom: '10px' }}>
                                            <TabList onChange={handleChange} aria-label="lab API tabs example">
                                                <Tab label="Limit" value="1" />
                                                <Tab label="Market" value="2" />
                                                <Tab label="Item Three" value="4" />
                                                <Tab label="Item Three" value="5" />
                                            </TabList>
                                        </Box>
                                        <TabPanel id="tabOutline" value="1">
                                            <Box sx={{ width: '100%', padding: "0px" }} >
                                                <Paper sx={{ width: '100%', padding: '0px', overflow: 'hidden' }}>
                                                    <span>Hello tab1</span>
                                                </Paper>
                                            </Box>
                                            <Box sx={{ display: 'flex', width: '100%' }}>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div>
                                                            <FormControl sx={{ bottom: '10px', width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={"61745,5"}
                                                                    onChange={"BGNKBNML"}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={"61745,5"}
                                                                    onChange={"BGNKBNML"}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ display: 'flex' }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">25%</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">50%</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">75%</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">100%</FormHelperText>
                                                                </Box>
                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={"61745,5"}
                                                                    onChange={"BGNKBNML"}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" sx={{ m: 1, width: "90%", backgroundColor: '#03675b' }} disableElevation>
                                                                BUY STORJ
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div sx={{ display: 'flex' }}>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={"61745,5"}
                                                                    onChange={"BGNKBNML"}
                                                                    endAdornment={<InputAdornment position="end" ><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        // 'style':
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>

                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={"61745,5"}
                                                                    onChange={"BGNKBNML"}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ display: 'flex' }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">25%</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">50%</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">75%</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">100%</FormHelperText>
                                                                </Box>
                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={"61745,5"}
                                                                    onChange={"BGNKBNML"}
                                                                    // hiddenLabel={true}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" color="error" sx={{ m: 1, width: "90%" }} disableElevation>
                                                                SELL USDT
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                            </Box>

                                        </TabPanel>
                                        <TabPanel value="2">Item Two</TabPanel>
                                        <TabPanel value="3">Item Three</TabPanel>
                                    </TabContext>
                                </Box>
                            </Paper>
                        </Box>
                    </Hidden>

                    <Hidden xsDown>
                        <Hidden >
                            <Box>
                                <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                                    <Box sx={{display:'flex' }}>
                                    Pairs
                                    <ButtonGroup sx={{marginLeft:'50px',height:"25px"}} aria-label="outlined primary button group">
                                        <Button>BTC</Button>
                                        <Button>ETH</Button>
                                        <Button>USDT</Button>
                                    </ButtonGroup>
                                    </Box>
                                    <TableContainer sx={{ maxHeight: 440 }}>
                                        <Table stickyHeader aria-label="sticky table">
                                            <TableHead>
                                                <TableRow>
                                                    {columns.map((column) => (
                                                        <TableCell id="tablecell"
                                                            key={column.id}
                                                            align={column.align}
                                                            style={{ minWidth: column.minWidth }}
                                                        >
                                                            {column.label}
                                                        </TableCell>
                                                    ))}
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {rows
                                                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                                    .map((row) => {
                                                        return (
                                                            <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                                                {columns.map((column) => {
                                                                    const value = row[column.id];
                                                                    return (
                                                                        <TableCell id="tablecell" key={column.id} align={column.align}>
                                                                            {column.format && typeof value === 'number'
                                                                                ? column.format(value)
                                                                                : value}
                                                                        </TableCell>
                                                                    );
                                                                })}
                                                            </TableRow>
                                                        );
                                                    })}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                    {/* <TablePagination
                                        rowsPerPageOptions={[10, 25, 100]}
                                        component="div"
                                        count={rows.length}
                                        rowsPerPage={rowsPerPage}
                                        page={page}
                                        onPageChange={handleChangePage}
                                        onRowsPerPageChange={handleChangeRowsPerPage}
                                    /> */}
                                </Paper>
                                <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                                <Box sx={{display:'flex' }}>
                                  Trade history
                                    <ButtonGroup sx={{marginLeft:'12px',height:"25px"}} aria-label="outlined primary button group">
                                        <Button>Yours</Button>
                                        <Button>Market</Button>
                                    </ButtonGroup>
                                    </Box>
                                    <TableContainer sx={{ maxHeight: 440 }}>
                                        <Table stickyHeader aria-label="sticky table">
                                            <TableHead>
                                                <TableRow>
                                                    {columns.map((column) => (
                                                        <TableCell
                                                            id="tablecell"
                                                            key={column.id}
                                                            align={column.align}
                                                            style={{ minWidth: column.minWidth }}
                                                        >
                                                            {column.label}
                                                        </TableCell>
                                                    ))}
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {rows
                                                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                                    .map((row) => {
                                                        return (
                                                            <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                                                {columns.map((column) => {
                                                                    const value = row[column.id];
                                                                    return (
                                                                        <TableCell id="tablecell" key={column.id} align={column.align}>
                                                                            {column.format && typeof value === 'number'
                                                                                ? column.format(value)
                                                                                : value}
                                                                        </TableCell>
                                                                    );
                                                                })}
                                                            </TableRow>
                                                        );
                                                    })}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                    {/* <TablePagination
                                        rowsPerPageOptions={[10, 25, 100]}
                                        component="div"
                                        count={rows.length}
                                        rowsPerPage={rowsPerPage}
                                        page={page}
                                        onPageChange={handleChangePage}
                                        onRowsPerPageChange={handleChangeRowsPerPage}
                                    /> */}
                                </Paper>
                            </Box>
                        </Hidden>
                    </Hidden>
                </div>
            </div>
        </Box>
    );
}

TradChart.propTypes = {
    width: PropTypes.oneOf(['lg', 'md', 'sm', 'xl', 'xs']).isRequired,
};

export default withWidth()(TradChart);
