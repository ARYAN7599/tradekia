import React from 'react';
import Paper from '@material-ui/core/Paper';
import TableScrollbar from 'react-table-scrollbar';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Loader from "../../../components/Loader/Loader";
import Box from '@mui/material/Box';
import { w3cwebsocket as W3CWebSocket } from "websocket";
import { Oval } from 'react-loader-spinner';
import { toast } from 'react-toastify';
import axios from "axios";
import '@djthoms/pretty-checkbox';
import "../TradChart.css";
import { Co2Sharp } from '@mui/icons-material';
const Torders = (props) => {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [value, setValue] = React.useState('1');
    const [newbit, setNewbit] = React.useState([]);
    const [newAitems, setNewAitems] = React.useState([]);
    const [aitems, setAItems] = React.useState([]);
    const [bitems, setBItems] = React.useState([]);
    const [isrander, setIsrander] = React.useState();
    const [ws, setWebsocket] = React.useState(null);
    const [client, setClient] = React.useState({});
    const [pair, setPair] = React.useState(props.pairdata);
    const [isaLoading, setIsaLoading] = React.useState(true);
    const [isbLoading, setIsbLoading] = React.useState(true)
    const getAskAndBit = async () => {

        try {
            let config = {
                method: 'GET',
                // url: `https://fapi.binance.com/fapi/v1/depth?symbol=${props.pairdata}&limit=20`
                url: `https://ftx.com/api/futures`
            };
            await axios(config)
                .then(function (response) {
                    let res = response.data;
                    console.log("hello4545",response); 
                    // let askdata=res.asks;
                    // let bidsdata=res.bids;
                    // if (aitems?.length === 0) {
                    //     askdata.forEach((e, i) => {
                    //         const result = aitems.find((el) => {
                    //             if (el.price ===parseFloat(e[0]) && el.amount === parseFloat(e[1])) return true;
                    //         });
                    //         if (result === undefined) {
                    //             let p =parseFloat(e[0]);
                    //             let amount = parseFloat(e[1]);
                    //             let price = p-(p*0.2)/100;
                    //             let d = createData(price, amount);
                    //             aitems.push(d);
                    //         }
                    //     });
                    // }
                    // if (bitems?.length === 0) {
                    //     bidsdata.forEach((e, i) => {
                    //         const result = bitems.find((el) => {
                    //             if (el.price===parseFloat(e[0]) && el.amount === parseFloat(e[1])) return true;
                    //         });
                    //         if (result === undefined) {
                    //             let p =parseFloat(e[0]);
                    //             let amount = parseFloat(e[1]);
                    //             let price = p-(p*0.2)/100;
                    //             let d = createData(price, amount);
                    //             bitems.push(d);
                    //         }
                    //     });
                    // }
                    // setNewbit(bidsdata);
                    // setNewAitems(askdata);    

                }).catch(err => console.log(err));
        } catch (error) {
            toast.error(error.message, {
                position: "bottom-center",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        };
    };
    const connect = (client) => {
        // var client = new W3CWebSocket(`wss://fstream.binance.com/ws/${pair}@depth10@500ms`);
        client.onopen = function () {
            console.log('.... some message the I must send when I connect .....');
        };

        client.onmessage = (message) => {
            const json = JSON.parse(message.data);
           
            const add = json.a;
            const bit = json.b;
         
            if (aitems?.length === 0) {
                add.forEach((e, i) => {
                    const result = aitems.find((el) => {
                        if (parseInt(el.price) === parseInt(e[0]) && parseInt(el.amount) === parseInt(e[1])) return true;
                    });
                    if (result === undefined) {
                        let p = parseFloat(e[0]);
                        let amount = parseFloat(e[1]);
                        let price = p - (p * 0.2) / 100;
                        let d = createData(price, amount);
                        aitems.push(d);
                    }
                });

            }
            if (bitems?.length === 0) {
                bit.forEach((e, i) => {
                    const result = bitems.find((el) => {
                        if (el.price === parseFloat(e[0]) && el.amount === parseFloat(e[1])) return true;
                    });
                    if (result === undefined) {
                        let p = parseFloat(e[0]);
                        let amount = parseFloat(e[1]);
                        let price = p - (p * 0.2) / 100;
                        let d = createData(price, amount);
                        bitems.push(d);
                    }
                });

            }
            setIsbLoading(false);
            setIsaLoading(false);
            setNewbit(bit);
            setNewAitems(json.a);

        };

        client.onclose = function (e) {
            console.log('Socket is closed. Reconnect will be attempted in 1 second.', e.reason);
            setTimeout(function () {
                connect();
            }, 1000);
        };
        client.onerror = function (err) {
            console.error('Socket encountered error: ', err.message, 'Closing socket');
            client.close();
        };
    }





    // const depthdata = async () => {
    //     console.log("befor", isrander);
    //     if (isrander) {
    //         console.log("jndfjkdf", isrander);
    //         try {
    //             const client = new W3CWebSocket(`wss://fstream.binance.com/ws/${props.pairdata}@depth10@500ms`);
    //             if (client.readyState === 0 && client.onerror === null) {
    //                 // const client = new W3CWebSocket(`wss://fstream.binance.com/ws/!bookTicker`);
    //                 setIsrander(false);
    //                 setTimeout(() => {
    //                 client.onmessage = (message) => {
    //                     const json = JSON.parse(message.data);
    //                     const add = json.a;
    //                     const bit = json.b;

    //                     if (aitems?.length === 0) {
    //                         add.forEach((e, i) => {
    //                             const result = aitems.find((el) => {
    //                                 if (el.price === parseFloat(e[0]) && el.amount === parseFloat(e[1])) return true;
    //                             });
    //                             if (result === undefined) {
    //                                 let p = parseFloat(e[0]);
    //                                 let amount = parseFloat(e[1]);
    //                                 let price = p - (p * 0.2) / 100;
    //                                 let d = createData(price, amount);
    //                                 aitems.push(d);
    //                             }
    //                         });
    //                     }
    //                     if (bitems?.length === 0) {
    //                         bit.forEach((e, i) => {
    //                             const result = bitems.find((el) => {
    //                                 if (el.price === parseFloat(e[0]) && el.amount === parseFloat(e[1])) return true;
    //                             });
    //                             if (result === undefined) {
    //                                 let p = parseFloat(e[0]);
    //                                 let amount = parseFloat(e[1]);
    //                                 let price = p - (p * 0.2) / 100;
    //                                 let d = createData(price, amount);
    //                                 bitems.push(d);
    //                             }
    //                         });
    //                     }
    //                     setNewbit(bit);
    //                     setNewAitems(json.a);

    //                 };
    //             }, 2000);
    //             }
    //         } catch(error){
    //           console.log("error",error);
    //           return true;  
    //         } finally {
    //             setIsrander(false);
    //         }
    //     }
    // }

    // setInterval(() => {
    //     setIsrander(true);
    //     depthdata();
    // },3000);

    //    React.useEffect(()=>{

    //    })
    // console.log("hdsfdsf", aitems);
    React.useEffect(() => {
        let ul = `wss://fstream.binance.com/ws/${pair}@depth10@500ms`
        // if (location?.state?.pairdata) {
        //     console.log("lllll000", location?.state?.pairdata);
        //     ul = `wss://fstream.binance.com/ws/${location?.state?.pairdata}@ticker`
        //     setPair(location?.state?.pairdata);
        // }
        getAskAndBit(); 
        if (client.readyState === 1) {
            client.close();
            client.onclose = (e) => {
                console.log('Socket is closed. Reconnect TTTTTTTTTTTTwill be attempted in 112 second.');
            };
        }
        let c = new W3CWebSocket(ul);
      
        setClient(c);
        connect(c);
    }, []);
    React.useEffect(() => {
        if (client.readyState === 1) {
            client.close();
            client.onclose = (e) => {
                console.log('Socket is closed. Reconnect order TTTTTTT2222222will be attempted in 112 second.', e.reason);
                let cn = new W3CWebSocket(`wss://fstream.binance.com/ws/${props.pairdata}@depth10@500ms`);
                
                setPair(props.pairdata);
                // setAItems([]);
                // setBItems([]);
                setIsaLoading(true);
                setIsbLoading(true);
                setClient(cn);
                connect(cn);
            };
        }
    }, [props.pairdata]);
    // React.useEffect(() => {
    //     console.log("TorderPair", props.pairdata);
    //     setPair(props.pairdata);
    // }, [])

    React.useEffect(() => {

        try {
            return updateData(), updatebitData();
        } catch (error) {
            console.error(error);
        } finally {
            setIsrander(false);
        }
    }, [newAitems, newbit])

    // setInterval(() => {
    //     getAskAndBit();
    // },2000);
    const updateData = () => {
        return aitems.forEach((it, j) => {
            newAitems.forEach((row, i) => {
                if (parseInt(row[0]) === parseInt(it.price)) {

                    let p = parseFloat(row[0]);
                    let a = parseFloat(row[1]);
                    aitems[j] = createData(p, a);
                }
            })
        })
    }
    const updatebitData = () => {
        return bitems.forEach((it, j) => {
            newbit.forEach((row, i) => {
                if (parseInt(row[0]) == parseInt(it.price)) {
                    let p = parseFloat(row[0]);
                    let a = parseFloat(row[1]);
                    bitems[j] = createData(p, a);
                }
            })
        })

    }

    // console.log("aitems",aitems);
    // console.log("bitems",typeof bitems[0].price);
    // if (bitems.length < 1) {
    //     return <Loader />;
    // }

    const columns = [
        {
            id: 'price',
            label: 'Price',
            minWidth:50,
            align: 'right',
            cellStyle: {
                color: "red"
            },
            // cellStyle: (e, rowData) => {
            //     console("rowcolorcode",rowData+"hdfhhdfhj"+e); 
            //     if (!rowData) {
            //       return { color: "red" };
            //     }
            //   },
            // cellClassName: (params) => {
            //     return params.getValue(params.id, "change") > 0
            //       ? "greenColor"
            //       : "redColor";
            //   },
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'amount',
            label: 'Amount',
            minWidth: 50,
            align: 'right',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'total',
            label: 'Total',
            minWidth: 50,
            align: 'right',
            format: (value) => value.toFixed(2),
        },
    ];
    const columnsBit = [
        {
            id: 'price',
            label: 'Price',
            minWidth: 50,
            align: 'right',
            cellStyle: {
                color: "#11cd83"
            },

            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'amount',
            label: 'Amount',
            minWidth: 50,
            align: 'right',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'total',
            label: 'Total',
            minWidth:50,
            align: 'right',
            format: (value) => value.toFixed(2),
        },
    ];
    function createData(price, amount) {
        const total = (price * amount);
        return { price, amount, total };
    }
    
    return (
        <Box>
            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                <TableContainer sx={{ maxHeight: 440 }}>
                    Orders Books
                    <TableScrollbar  rows={13}>
                    <Table stickyHeader aria-label="sticky table">
                        <TableHead>

                            <TableRow>
                                {columns.map((column) => (
                                    <TableCell id="tablecell"
                                        key={column.id}
                                        align={column.align}
                                        style={{ minWidth: column.minWidth }}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {
                                isaLoading ?
                                    <TableRow hover role="checkbox" tabIndex={-1} >
                                        <TableCell id="tablecell" align={"center"} >

                                        </TableCell>
                                        <TableCell id="tablecell" align={"center"} >
                                            <Oval color="#00BFFF" height={40} width={40} />
                                        </TableCell>

                                    </TableRow>
                                    : aitems
                                        // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                        .map((row) => {
                                            return (
                                                <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                                    {columns.map((column) => {
                                                        const value = row[column.id];
                                                        return (
                                                            <TableCell id="tablecell" key={column.id} align={column.align} style={column.cellStyle}>
                                                                {column.format && typeof value === 'number'
                                                                    ? column.format(value)
                                                                    : value}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                            );
                                        })}
                        </TableBody>
                    </Table>
                    </TableScrollbar>
                </TableContainer>

            </Paper>
            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                <TableContainer sx={{ maxHeight: 440 }}>
                <TableScrollbar  rows={13}>
                    <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                            <TableRow>
                                {columnsBit.map((column) => (
                                    <TableCell id="tablecell"
                                        key={column.id}
                                        align={column.align}
                                        style={{ minWidth: column.minWidth }}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {
                                isbLoading ?
                               
                                    <TableRow hover role="checkbox" tabIndex={-1} >
                                        <TableCell id="tablecell" align={"center"} >

                                        </TableCell>
                                        <TableCell id="tablecell" align={"center"} >
                                            <Oval color="#00BFFF" height={40} width={40} />
                                        </TableCell>

                                    </TableRow>
                                    : bitems
                                        // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                        .map((row, i) => {
                                            return (
                                                <TableRow hover role="checkbox" tabIndex={-1} key={i}>
                                                    {columnsBit.map((column) => {
                                                        const value = row[column.id];
                                                        return (
                                                            <TableCell id="tablecell" key={column.id} align={column.align} style={column.cellStyle} >
                                                                {column.format && typeof value === 'number'
                                                                    ? column.format(value)
                                                                    : value}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                            );
                                        })}
                        </TableBody>
                    </Table>
                    </TableScrollbar>
                </TableContainer>
              
            </Paper>
        </Box>
    )
}

export default Torders;