import React from 'react';
import Paper from '@material-ui/core/Paper';
import TableScrollbar from 'react-table-scrollbar';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import TableRow from '@mui/material/TableRow';
import ButtonGroup from '@mui/material/ButtonGroup';
import { w3cwebsocket as W3CWebSocket } from "websocket";
import '@djthoms/pretty-checkbox';
import "../TradChart.css";
import { toast } from 'react-toastify';
import { Oval } from  'react-loader-spinner';
import axios from "axios";

const Thistory = (props) => {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [value, setValue] = React.useState('1');
    const [historydata, setHistorydata] = React.useState([]);
    const [client, setClient] = React.useState({});
    const [isLoading,setIsLoading]=React.useState(true);
    const [pair,setPair]=React.useState(props.pairdata);
    // const client = new W3CWebSocket(`wss://fstream.binance.com/ws/btcusdt@compositeIndex`);
    // if(client.readyState===0 && client.onerror===null){
    //     client.onmessage = (message) => {
    //         const json = JSON.parse(message.data);
    //         console.log("jfdhfdhj222",json); 
    //         // if (historydata?.length === 0) {
    //         //     json.forEach((e, i) => {
    //         //         const result = items.find((el) => {
    //         //             if (el === e.s) return true;
    //         //         });
    //         //         if (result === undefined) {
    //         //             let d = changeformate(e)
    //         //             items.push(d);
    //         //         }
    //         //     });
    //         // }

    //         // setNewTrlist(json);
    //         // setIsrander(true);
    //     };
    // }else{
    //     console.log("errorsection",client.onerror)
    //     // setIsrander(false);
    //     // return false; 
    // }
    const getReferralTeam = async (url) => {
        
        try {
         
            let config = {
                method: 'GET',
                // url: `https://fapi.binance.com/fapi/v1/trades?symbol=${props.pairdata}&limit=20`
                url:url
            };

            await axios(config)
                .then(function (response) {
                    let res = response.data;
                    // let ch=getTreeData(arr); 
                    // console.log("llll",ch);
                    // if (historydata?.length === 0) {
                        res.forEach((e,i)=>{
                            let t = new Date (e.time);
                            res[i].time=t.toLocaleTimeString();
                            // const result = items.find((el) => {
                            //     if (el === e.s) return true;
                            // });
                            // if (result === undefined) {
                            //     let d = changeformate(e)
                            //     items.push(d);
                            // }
                        });
                        setHistorydata(res); 
                        setIsLoading(false);
                    // }
                    // if (members?.length === 0) {
                    //     for (let i = 0; i < ch?.length; i++) {
                    //         members.push(ch[i]);
                    //     }  
                    // }  
                    // setIsrander(false);      
                }).catch(err => console.log(err));
        } catch (error) {
            toast.error(error.message, {
                position: "bottom-center",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            setIsLoading(false);
        };
    };

    // setInterval(() => {
    //     let u=`https://fapi.binance.com/fapi/v1/trades?symbol=${pair}&limit=20`;
    //     getReferralTeam(u);
    // },3000);
    // let internationalNumberFormat = new Intl.NumberFormat('en-US');
    // const changeformate = (r) => {
    //     let volChang = internationalNumberFormat.format(((r.q) / 1000000).toFixed(2));
    //     r.c = internationalNumberFormat.format(r.c);
    //     r.h = internationalNumberFormat.format(r.h);
    //     r.l = internationalNumberFormat.format(r.l);
    //     r.P = r.P + " %";
    //     r.q = volChang.toLocaleString("en", { useGrouping: false, minimumFractionDigits: 2 }) + "M";
    //     return r;

    // }
    React.useEffect(() => {
        let u=`https://fapi.binance.com/fapi/v1/trades?symbol=${props.pairdata}&limit=20`;
        setPair(props.pairdata);
        getReferralTeam(u);
    }, [])
    React.useEffect(() => {
        // if (client.readyState === 1) {
        //     client.close();
        //     client.onclose = (e) => {
        //         console.log('Socket is closed. Reconnect order TTTTTTT2222222will be attempted in 112 second.', e.reason);
        //         let cn = new W3CWebSocket(`wss://fstream.binance.com/ws/${props.pairdata}@depth10@500ms`);
        //         setPair(props.pairdata); 
        //         // setAItems([]);
        //         // setBItems([]);
        //         setIsaLoading(true);
        //         setIsbLoading(true); 
        //         setClient(cn);
        //         connect(cn);
        //     };
        // }
        let u=`https://fapi.binance.com/fapi/v1/trades?symbol=${props.pairdata}&limit=20`;
        setIsLoading(true);
        setPair(props.pairdata);
        getReferralTeam(u); 
    }, [props.pairdata]);
    const columns = [
        {
            id: 'price',
            label: 'Price',
            minWidth: 60,
            align: 'right',
            cellStyle: (rowData) => {
                return  (rowData.isBuyerMaker===true) ? { color: '#d9442e' }: { color: '#76b840' };
              },
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'qty',
            label: 'Amount',
            minWidth: 60,
            align: 'right',
            cellStyle: (rowData) => {
                return  (rowData.isBuyerMaker) ? { color: '#121212' }: { color: '#121212' };
              },
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'time',
            label: 'Time',
            minWidth: 60,
            align: 'right',
            cellStyle: (rowData) => {
                return  (rowData.isBuyerMaker) ? { color: '#121212' }: { color: '#121212' };
              },
            format: (value) => value.toFixed(2),
        },
    ];
    function createData(price, amount) {
        const total = price + amount;
        return { price, amount, total };
    }
   
    return (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
            <Box sx={{ display: 'flex' }}>
                Trade history
                <ButtonGroup sx={{ marginLeft: '12px', height: "25px"}} aria-label="outlined primary button group">
                <Button     sx={{backgroundColor: "antiquewhite"}}>Market</Button>
                    <Button disableRipple={false}>Yours</Button>
                    
                </ButtonGroup>
            </Box>
            
            <TableContainer sx={{ maxHeight: 440 }}>
            <TableScrollbar  rows={10}>
                <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                        <TableRow>
                            {columns.map((column) => (
                                <TableCell
                                    id="tablecell"
                                    key={column.id}
                                    align={column.align}
                                    style={{ minWidth: column.minWidth }}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                         isLoading?
                         <TableRow hover role="checkbox" tabIndex={-1} >
                         <TableCell id="tablecell" align={"center"} >
                         </TableCell>
                         <TableCell id="tablecell" align={"center"} >
                             <Oval color="#00BFFF" height={40} width={40} />
                         </TableCell>
                     </TableRow>
                        :historydata
                            // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row) => {
                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                        {columns.map((column) => {
                                            const value = row[column.id];
                                            return (
                                                <TableCell id="tablecell" key={column.id} align={column.align} style={column.cellStyle(value)}>
                                                    {column.format && typeof value === 'number'
                                                        ? column.format(value)
                                                        : value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
                </TableScrollbar>
            </TableContainer>

        </Paper>
    )
}

export default Thistory;