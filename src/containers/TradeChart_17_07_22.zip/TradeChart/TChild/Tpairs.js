import React from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import ButtonGroup from '@mui/material/ButtonGroup';
import Paper from '@material-ui/core/Paper';
import TableScrollbar from 'react-table-scrollbar';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { w3cwebsocket as W3CWebSocket } from "websocket";
import { toast } from 'react-toastify';
import { Oval } from  'react-loader-spinner';
import axios from "axios";
import '@djthoms/pretty-checkbox';
import "../TradChart.css";
import { WifiLock } from '@mui/icons-material';
const Tpairs = (props) => {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [value, setValue] = React.useState('1');
    const [newTrlist, setNewTrlist] = React.useState([]);
    const [items, setItems] = React.useState([]);
    const [isrander, setIsrander] = React.useState(false);
    const [pair, setPair] = React.useState();
    const [isLoading, setIsLoading] = React.useState(true);
    const [allsymble, setAllsymble] = React.useState([]);
    //  const get24hrticker= async () => {
    //     try {
    //         let config = {
    //             method: 'GET',
    //             url: `https://fapi.binance.com/fapi/v1/ticker/24hr`
    //          };
    //         await axios(config)
    //             .then(function (response) {
    //                 console.log("responce",response); 
    //                 let res = response.data;
    //                 // if (items.length === 0) {
    //                 //     res.forEach((e, i) => {
    //                 //         const result = items.find((el) => {
    //                 //             if (el && el.symbol === e.symbol) return true;
    //                 //         });
    //                 //         if (result === undefined) {
    //                 //             let d = change24hrformate(e)
    //                 //             items.push(d);
    //                 //         }
    //                 //     });
    //                 // }
    //                 setNewTrlist(res);    
    //             }).catch(err => console.log(err));
    //     } catch (error) {
    //         toast.error(error.message, {
    //             position: "bottom-center",
    //             autoClose: 5000,
    //             hideProgressBar: false,
    //             closeOnClick: true,
    //             pauseOnHover: true,
    //             draggable: true,
    //             progress: undefined,
    //         });
    //     };
    // };

    // const client = new W3CWebSocket(`wss://fstream.binance.com/ws/btcusdt@depth10@5000ms`);
    // setInterval(() => {
    // }, 2000);
    // const getalltickerdatat = () => {
    //     if(isrander){
    //     const client = new W3CWebSocket('wss://fstream.binance.com/ws/!ticker@arr');
    //     if (client.readyState === 0&& client.onerror === null) {
    //         client.onmessage = (message) => {
    //             const json = JSON.parse(message.data);
    //             if (items.length === 0) {
    //                 json.forEach((e, i) => {
    //                     const result = items.find((el) => {
    //                         if (el === e.s) return true;
    //                     });
    //                     if (result === undefined) {
    //                         let d = changeformate(e)
    //                         items.push(d);
    //                     }
    //                 });
    //             }
    
    //             setNewTrlist(json);
    //             setIsrander(false);
    //         };
    //     } else {
    //         console.log("errorsection", client.onerror)
    //         // setIsrander(false);
    //         // return true; 
    //     }
    // }
    // }
   
    const connect=()=>{
        var client = new W3CWebSocket(`wss://fstream.binance.com/ws/!ticker@arr`);
        client.onopen = function() {
          // subscribe to some channels
        //   client.send(JSON.stringify({
           
              //.... some message the I must send when I connect ....
        //   }));
        console.log('.... some message the I must send when I connect .....');
        };
      
        client.onmessage = (message) => {
            const json = JSON.parse(message.data);
            if (items.length === 0) {
                json.forEach((e, i) => {
                    const result = items.find((el) => {
                        if (el === e.s) return true;
                    });
                    if (result === undefined) {
                        var str = e.s;
                        var substr = str.substring(str.length-4, str.length);
                        if(substr!="BUSD"){
                            let d = changeformate(e)
                            items.push(d);
                        }
                       
                    }
                });
            }
            setIsLoading(false);
            setNewTrlist(json);
            setIsrander(false);
        };
      
        client.onclose = function(e) {
          console.log('Socket is closed. Reconnect will be attempted in 1 second.', e.reason);
          setTimeout(function() {
            connect();
          }, 1000);
        };
      
        client.onerror=function(err) {
          console.error('Socket encountered error: ', err.message, 'Closing socket');
          client.close();
        };
      }

    // console.log("hdsfdsf",aitems); 
    React.useEffect(()=>{
        // getalltickerdatat();
        getallSymble();
        connect();
    },[]); 
 
    React.useEffect(() => {
        try {
            addNepair();
            return updateData();
        } catch (error) {
            console.error(error);
        } finally {
            setIsrander(false);
        }
    }, [newTrlist]);
    // setInterval(() => {
    //     setIsrander(true);
    //     getalltickerdatat();
    // },2000);

    let internationalNumberFormat = new Intl.NumberFormat('en-US');
    const changeformate = (r) => {
        let volChang = internationalNumberFormat.format(((r.q) / 1000000).toFixed(2));
        r.c = internationalNumberFormat.format(r.c);
        r.h = internationalNumberFormat.format(r.h);
        r.l = internationalNumberFormat.format(r.l);
        r.P = r.P + " %";
        r.q = volChang.toLocaleString("en", { useGrouping: false, minimumFractionDigits: 2 }) + "M";
        return r;

    }
    // const change24hrformate = (r) => {
    //     let volChang = internationalNumberFormat.format(((r.quoteVolume) / 1000000).toFixed(2));
    //     r.lastPrice = internationalNumberFormat.format(r.lastPrice);
    //     r.highPrice = internationalNumberFormat.format(r.highPrice);
    //     r.lowPrice = internationalNumberFormat.format(r.lowPrice);
    //     r.priceChangePercent = r.priceChangePercent + " %";
    //     r.quoteVolume = volChang.toLocaleString("en", { useGrouping: false, minimumFractionDigits: 2 }) + "M";
    //     return r;

    // }
    const updateData = () => {
        return items.forEach((it, j) => {
            newTrlist.forEach((row, i) => {
                if (row.s === it.s) {
                    items[j] = changeformate(row);
                }
            })
        })

    }
    const changePair = (e, rowData) => {
        let p = rowData?.s.toLowerCase();
        setPair(p);
        props.pairdata(p);
    }
    const columns = [
        {
            id: 's',
            label: 'Pair',
            minWidth:50,
            align: 'right',
            cellStyle: (rowData) => {

                return (rowData.P.slice(0, 1) == "-") ? { color: '#121212' } : { color: '#121212' };
            },
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'c',
            label: 'Price',
            minWidth: 50,
            align: 'right',
            cellStyle: (rowData) => {

                return (rowData.P.slice(0, 1) == "-") ? { color: '#76b840' } : { color: '#d9442e' };
            },
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'P',
            label: 'Change',
            minWidth: 50,
            align: 'right',
            cellStyle: (rowData) => {

                return (rowData.P.slice(0, 1) == "-") ? { color: '#d9442e' } : { color: '#76b840' };
            },
            format: (value) => value.toFixed(2),
        },
    ];
    const addNepair=()=>{
        for(var i = 0; i < allsymble.length; i++) {
              let syme = items.find((ele) => {
                  if (ele.s === allsymble[i].symble) return true;
              });
              if(syme===undefined){
                  let symed = newTrlist.find((ele) => {
                      if (ele.s === allsymble[i].symble) return ele;
                  });
                //   console.log("allsymble",symed);
                  if(symed){
                    //   console.log("ghhh",symed); 
                         let da = changeformate(symed);
                          items.push(da); 
                          return; 
                  }
              }
            }
      }
  
    const getallSymble = () => {
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }
        axios.post(`https://api.tradekia.com/api/getAllSymble`)
            .then(res => {
               
                setAllsymble(res.data.data);

            }).catch(error => {
                console.log("error", error);
            });
    }

    return (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
            <Box sx={{ display: 'flex' }}>
                Pairs
                <ButtonGroup sx={{ marginLeft: '20px',backgroundColor:"bisque", height: "25px" }} aria-label="outlined primary button group">
                    {/* <Button>BTC</Button>
                    <Button>ETH</Button> */}
                    <Button>USDT</Button>
                </ButtonGroup>
            </Box>
            <TableContainer sx={{ maxHeight: 440 }}>
            <TableScrollbar  rows={15}>
                
                <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                        <TableRow>
                            {columns.map((column) => (
                                <TableCell id="tablecell"
                                    key={column.id}
                                    align={column.align}
                                    style={{ minWidth: column.minWidth }}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                             isLoading?
                             <TableRow hover role="checkbox" tabIndex={-1} >
                             <TableCell id="tablecell" align={"center"} >
                             </TableCell>
                             <TableCell id="tablecell" align={"center"} >
                                 <Oval color="#00BFFF" height={40} width={40} />
                             </TableCell>
                         </TableRow>
                        :items
                            // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row, i) => {
                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={i}>
                                        {columns.map((column) => {
                                            const value = row[column.id];
                                            return (
                                                <TableCell id="tablecell" key={column.id} align={column.align} onClick={(e) => { changePair(e, row); }} style={column.cellStyle(row)}>
                                                  {column.format && typeof value === 'number'
                                                        ? column.format(value)
                                                        : value}    
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
                </TableScrollbar>
            </TableContainer>
       
        </Paper>
    )
}

export default Tpairs;