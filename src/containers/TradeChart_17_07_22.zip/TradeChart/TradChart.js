import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Hidden from '@material-ui/core/Hidden';
import withWidth from '@material-ui/core/withWidth';
import Slider from "react-slick";
import Typography from '@mui/material/Typography';
import Sliders from '@mui/material/Slider';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import DollarSvg from "../../assets/images/totalBalance.svg";
import Box from '@mui/material/Box';
import TradingViewWidget from 'react-tradingview-widget';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import OutlinedInput from '@mui/material/OutlinedInput';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import FormHelperText from '@mui/material/FormHelperText';
import FormControlLabel from '@mui/material/FormControlLabel';
import Badge from '@mui/material/Badge';
import Switch from '@mui/material/Switch';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { w3cwebsocket as W3CWebSocket } from "websocket";
import { useLocation, useNavigate } from "react-router-dom";
// import Moment from 'react-momen
import Moment from 'moment';


// import Button from '@mui/material/Button';
import './TradChart.css';
//chield Component
import Torders from './TChild/Torders';
import Tordergreen from './TChild/Tordergreen';
import Tpairs from './TChild/Tpairs';
import Thistory from './TChild/Thistory';
import { event } from 'jquery';
import axios from 'axios';
import { connect } from 'react-redux';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import swal from 'sweetalert';
import Swal from 'sweetalert2';
const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
        flex: '1 0 auto',
        margin: theme.spacing(1),
    },
}));

function TradChart(props) {
    const [valuep, setValuep] = React.useState(1);
    const [valuepra, setValuepra] = React.useState(1);
    const [valueLST, setValueLST] = React.useState(1)
    const [valueprasail, setValueprasail] = React.useState(1);
    const [valuepMar, setValuepMar] = React.useState(1);
    const [valuepraMar, setValuepraMar] = React.useState(1);
    const [valueMarST, setValueMarST] = React.useState(1)
    const [valueprasailMar, setValueprasailMar] = React.useState(1);
    const location = useLocation();
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [value, setValue] = React.useState('1');
    const [newTrlist, setNewTrlist] = React.useState([]);
    const [items, setItems] = React.useState([]);
    const [isrander, setIsrander] = React.useState(false);
    const [pair, setPair] = React.useState('btcusdt');
    const [sy, setSy] = React.useState(`BINANCE:${pair?.toUpperCase()}`);
    const [lp, setLp] = React.useState('btcusdt');
    const [ch, setCh] = React.useState('btcusdt');
    const [client, setClient] = React.useState({});
    const [url, setUrl] = React.useState(`wss://fstream.binance.com/ws/${pair}@ticker`);
    const [hd, setHd] = React.useState({});
    const [limitPrice, setLimitPrice] = React.useState();
    const [limitqty, setlimitQty] = React.useState();
    const [limitTotal, setLimitTotal] = React.useState();
    const [etype, setEtype] = React.useState("limit");
    const [limitqtyp, setLimitqtyp] = React.useState();
    const [tWB, setTWB] = React.useState();
    const [rwA, setRwA] = React.useState();
    const [toSb, setTpSb] = React.useState();
    const [rswA, setRswA] = React.useState();
    const [issetLimtP, setIssetLimitP] = React.useState(false);
    const [sLimitPrice, setSLimitPrice] = React.useState();
    const [sLimitQty, setSLimitQty] = React.useState();
    const [sTotalAmount, setSTotalAmount] = React.useState();
    const [isrerander, setIsrerander] = React.useState(false);
    const [invisiblelb, setInvisiblelb] = React.useState(true);
    const [invisiblels, setInvisiblels] = React.useState(true);
    const [invisible, setInvisible] = React.useState(true);
    const [invisiblems, setInvisiblems] = React.useState(true);
    const [invisiblemb, setInvisiblemb] = React.useState(true);
    // const [invisible, setInvisible] = React.useState(false);
    const [timeLimit, setTimeLimit] = React.useState();
    const [marbyexprytime,setMarbyexprytime]=React.useState(); 
    const [marsalexprytime,setMarsalexprytime]=React.useState(); 
    const [limbyexprytime,setLimbyexprytime]=React.useState(); 
    const [limsalexprytime,setLimsalexprytime]=React.useState(); 
// Start code for timrlimit labale
function valueLabelFormat(value) {
    const units = ['Minutes', 'Hours', 'Days', 'Weeks', 'Month'];
    let unitIndex = 0;
    let scaledValue = value;
    let checkvalue = 60;
    while (scaledValue >= checkvalue && unitIndex < units.length - 1) {
        unitIndex += 1;
        if (units[unitIndex] === 'Minutes') {
            checkvalue = 60;
        } else if (units[unitIndex] === 'Hours') {
            checkvalue = 24;
            scaledValue = scaledValue - 59;
        } else if (units[unitIndex] === 'Days') {
            checkvalue = 7;
            scaledValue = scaledValue - 23;
        } else if (units[unitIndex] === 'Weeks') {
            checkvalue = 3;
            scaledValue = scaledValue - 6;
        } else if (units[unitIndex] === 'Month') {
            checkvalue = 2;
            scaledValue = scaledValue - 2;
        }
    }
    let d= new Date(); 
    // let d=new Date().toISOString().slice(0, 19).replace('T', ' '); 
    let exdate=dateAdd(d,units[unitIndex],scaledValue);
    
     let ed=(exdate)?exdate.toISOString().slice(0, 19).replace('T', ' '):exdate;
    
    setLimbyexprytime(ed);
    return `${scaledValue} ${units[unitIndex]}`;
}

function calculateValue(value) {
    return value;
}
function valueLabelFormatForPra(value) {
    let scaledValue = value;
    return scaledValue + ' (%)USDT';

}
function calculateValueForPra(value) {
    return value;
}

function valueLabelFormatForPraSail(value) {
    let scaledValue = value;
    return scaledValue + ' (%)USDT';

}
function calculateValueForPraSail(value) {
    return value;
}
function valueLabelFormatForLSaleTime(value) {
    const units = ['Minute', 'Hours', 'Days', 'Weeks', 'Month'];
    let unitIndex = 0;
    let scaledValue = value;
    let checkvalue = 60;
    while (scaledValue >= checkvalue && unitIndex < units.length - 1) {
        unitIndex += 1;
        if (units[unitIndex] === 'Minute') {
            checkvalue = 60;
        } else if (units[unitIndex] === 'Hours') {
            checkvalue = 24;
            scaledValue = scaledValue - 59;
        } else if (units[unitIndex] === 'Days') {
            checkvalue = 7;
            scaledValue = scaledValue - 23;
        } else if (units[unitIndex] === 'Weeks') {
            checkvalue = 3;
            scaledValue = scaledValue - 6;
        } else if (units[unitIndex] === 'Month') {
            checkvalue = 2;
            scaledValue = scaledValue - 2;
        }
    }
    let d= new Date(); 
    let exdate=dateAdd(d,units[unitIndex],scaledValue);
    let ed=(exdate)?exdate.toISOString().slice(0, 19).replace('T', ' '):exdate;
    setLimsalexprytime(ed);
    return `${scaledValue} ${units[unitIndex]}`;
}

function calculateValueForLSaleTime(value) {
    return value;
}


function dateAdd(date, interval, units) {
    if(!(date instanceof Date)){
        return undefined;
    }else{
        var ret = new Date(date); //don't change original date
        var checkRollover = function() { if(ret.getDate() != date.getDate()) ret.setDate(0);};
        switch(String(interval).toLowerCase()) {
        //  case 'year'   :  ret.setFullYear(ret.getFullYear() + units); checkRollover();  break;
    //case 'quarter':  ret.setMonth(ret.getMonth() + 3*units); checkRollover();  break;
          case 'month'  :  ret.setMonth(ret.getMonth() + units); checkRollover();  break;
          case 'weeks'   :  ret.setDate(ret.getDate() + 7*units);  break;
          case 'days'    :  ret.setDate(ret.getDate() + units);  break;
          case 'hours'   :  ret.setTime(ret.getTime() + units*3600000);  break;
          case 'minutes' :  ret.setTime(ret.getTime() + units*60000);  break;
          case 'second' :  ret.setTime(ret.getTime() + units*1000);  break;
          default       :  ret = undefined;  break;
        }
        return ret;
    }
    
  }
///Market sections 
function valueLabelFormatMar(value) {
    const units = ['Minutes', 'Hours', 'Days', 'Weeks', 'Month'];
    let unitIndex = 0;
    let scaledValue = value;
    let checkvalue = 60;
    while (scaledValue >= checkvalue && unitIndex < units.length - 1) {
        unitIndex += 1;
        if (units[unitIndex] === 'Minutes') {
            checkvalue = 60;
        } else if (units[unitIndex] === 'Hours') {
            checkvalue = 24;
            scaledValue = scaledValue - 59;
        } else if (units[unitIndex] === 'Days') {
            checkvalue = 7;
            scaledValue = scaledValue - 23;
        } else if (units[unitIndex] === 'Weeks') {
            checkvalue = 3;
            scaledValue = scaledValue - 6;
        } else if (units[unitIndex] === 'Month') {
            checkvalue = 2;
            scaledValue = scaledValue - 2;
        }
    }
    let d= new Date(); 
    let exdate=dateAdd(d,units[unitIndex],scaledValue);
    let ed=(exdate)?exdate.toISOString().slice(0, 19).replace('T', ' '):exdate;
    setMarbyexprytime(ed);
    return `${scaledValue} ${units[unitIndex]}`;
}

function calculateValueMar(value) {
    return value;
}
function valueLabelFormatForPraMar(value) {
    let scaledValue = value;
    return scaledValue + ' (%)USDT';

}
function calculateValueForPraMar(value) {
    return value;
}

function valueLabelFormatForPraSailMar(value) {
    let scaledValue = value;
    return scaledValue + ' (%)USDT';

}
function calculateValueForPraSailMar(value) {
    return value;
}
function valueLabelFormatForMarSaleTime(value) {
    const units = ['Minute', 'Hours', 'Days', 'Weeks', 'Month'];
    let unitIndex = 0;
    let scaledValue = value;
    let checkvalue = 60;
    while (scaledValue >= checkvalue && unitIndex < units.length - 1) {
        unitIndex += 1;
        if (units[unitIndex] === 'Minute') {
            checkvalue = 60;
        } else if (units[unitIndex] === 'Hours') {
            checkvalue = 24;
            scaledValue = scaledValue - 59;
        } else if (units[unitIndex] === 'Days') {
            checkvalue = 7;
            scaledValue = scaledValue - 23;
        } else if (units[unitIndex] === 'Weeks') {
            checkvalue = 3;
            scaledValue = scaledValue - 6;
        } else if (units[unitIndex] === 'Month') {
            checkvalue = 2;
            scaledValue = scaledValue - 2;
        }
    }
    let d= new Date(); 
    let exdate=dateAdd(d,units[unitIndex],scaledValue);
    let ed=(exdate)?exdate.toISOString().slice(0, 19).replace('T', ' '):exdate;
    setMarsalexprytime(ed);
    return `${scaledValue} ${units[unitIndex]}`;
}

function calculateValueForMarSaleTime(value) {
    return value;
}
//end code for  timelime lable 
    var s = {
        className: "center",
        infinite: true,
        centerPadding: "20px",
        slidesToShow: 5,
        swipeToSlide: true,
        afterChange: function (index) {
            console.log(
                `Slider Changed to: ${index + 1}, background: #222; color: #bada55`
            );
        }
    }
    const [settings, setSettings] = React.useState(s);
    const navigate = useNavigate();
    const handleBadgeVisibilitylb = () => {
        setInvisiblelb(!invisiblelb);
    };
    const handleBadgeVisibilityls = () => {
        setInvisiblels(!invisiblels);
    }
    const handleBadgeVisibility = () => {
        setInvisible(!invisible);
    }
    const handleBadgeVisibilitymb = () => {
        setInvisiblemb(!invisiblemb);
    }
    const handleBadgeVisibilityms = () => {
        setInvisiblems(!invisiblems);
    }
    const handleSaleLimitPrice = (event) => {
        setSLimitPrice(event.target.value);
    }
    const HandileSaleLimitQty = (event) => {
        let to = (sLimitPrice * event.target.value);
        setSTotalAmount(to);
        // setRswA(toSb - to);
        setRswA(toSb - event.target.value);
        setSLimitQty(event.target.value);
        let lp=(to*100)/toSb;
        valueprasail(lp);
    }
    const handileSaleTotalAmount = (event) => {
        let qt = event.target.value / sLimitPrice;
        setSLimitQty(qt);
        // setLimitTotal(event.target.value);
        // setRswA(toSb - event.target.value);
        setRswA(toSb - qt);
        setSTotalAmount(event.target.value);
        let lp=(event.target.value*100)/toSb;
        valueprasail(lp);
    }
    const slimtQpHandler = (e, slpa) => {
        let q = (toSb * slpa) / 100;
        // let q = samount / sLimitPrice;
        let samount = sLimitPrice * q;
        setSLimitQty(q);
        setSTotalAmount(samount);
        setRswA(toSb - q);
    }
    // React.useEffect(()=>{
    //     console.log("Hellohdjdf"); 
    //     let q = (toSb * valuepra) / 100;
    //     // let q = samount / sLimitPrice;
    //     let samount = sLimitPrice * q;
    //     setSLimitQty(q);
    //     setSTotalAmount(samount);
    //     setRswA(toSb - q);
    // },[valuepra]);

    const limtQpHandler = (e, lpa) => {
        let bamount = (tWB * lpa) / 100;
        let q = bamount / limitPrice;
        setlimitQty(q);
        setLimitTotal(bamount);
        setRwA(tWB - bamount);
        setLimitqtyp(lpa);
    }

    const handileLimitTotal = (event) => {
        let qt = event.target.value / limitPrice;
        setlimitQty(qt);
        setLimitTotal(event.target.value);
        setRwA(tWB - event.target.value);
        let lp=(event.target.value*100)/tWB;
        setValuepra(lp);
    }
    const handleLimitQty = (event) => {
        let to = (limitPrice * event.target.value);
        setLimitTotal(to);
        setRwA(tWB - to);
       
        setlimitQty(event.target.value);
        let lp=(to*100)/tWB;
        setValuepra(lp);
    }
    const handleLimitPrice = (event) => {
        setLimitPrice(event.target.value);
    }
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const handleChangeLb = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValuep(newValue);
        }
    };
    const handleChangeForPra = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValuepra(newValue);
            let bamount = (tWB * newValue) / 100;
            let q = bamount / limitPrice;
            setlimitQty(q);
            setLimitTotal(bamount);
            setRwA(tWB - bamount);
            setLimitqtyp(newValue);
        }
    }
    const handleChangeForPraSail = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValueprasail(newValue);
        }
    }
    const handleChangeForlimitPraSailTime = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValueLST(newValue);
        }
    }
    //Market Slider
    const handleChangeMarb = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValuepMar(newValue);
        }
    };
    const handleChangeForPraMar = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValuepraMar(newValue);
        }
    }
    const handleChangeForPraSailMar = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValueprasailMar(newValue);
        }
    }
    const handleChangeForlimitPraSailTimeMar = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValueMarST(newValue);
        }
    }

    //End Marcket slider
    const handleTimeChange = (event) => {
        setTimeLimit(event.target.value);
    };
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    const classes = useStyles();
    const { width } = props;
    React.useEffect(() => {
        let ul = `wss://fstream.binance.com/ws/${pair}@ticker`
        if (location?.state?.pairdata) {
            ul = `wss://fstream.binance.com/ws/${location?.state?.pairdata}@ticker`
            setPair(location?.state?.pairdata);
        }
        if (client.readyState === 1) {
            client.close();
            client.onclose = (e) => {
                console.log('Socket is closed. Reconnect will be attempted in 112 second.');
            };
        }

        let c = new W3CWebSocket(ul);
        setClient(c);
        connect(c);
        setTimeout(() => {
            setIssetLimitP(true);
        }, 1000)
        getUserWaletAmount();
        getUserpairWaletAmount(pair);
    }, []);
    React.useEffect(() => {
        if (client.readyState === 1) {
            client.close();
            client.onclose = (e) => {
                let cn = new W3CWebSocket(`wss://fstream.binance.com/ws/${pair}@ticker`);
                setClient(cn);
                connect(cn);
            };
        }
        setTimeout(() => {
            setIssetLimitP(true);
        }, 1000)

    }, [pair]);

    React.useEffect(() => {
        setLimitPrice(hd.c);
        setSLimitPrice(hd.c);
        setIssetLimitP(false);
        getUserpairWaletAmount(hd.s);
    }, [issetLimtP]);
    React.useEffect(() => {
        setIssetLimitP(true);
    }, [hd.s]);

    // React.useEffect(()=>{
    //     getUserWaletAmount();
    //  setlimitQty();
    // setLimitTotal();

    // },[isrerander]);

    const connect = (client) => {
        client.onopen = function () {
            console.log('.... some message the I must send when I connect .....');
        };
        client.onmessage = (message) => {
            const json = JSON.parse(message.data);
            if (json?.length !== 0) {
                // let fd = changeformate(json);
                let fd = changehdformate(json);
                setHd(fd);
            }
        };

        client.onclose = function (e) {
            console.log('Socket is closed. Reconnect will be attempted in 1 second.', e.reason);
            setTimeout(function () {
                connect();
            }, 1000);
        };

        client.onerror = function (err) {
            console.error('Socket encountered error: ', err.message, 'Closing socket');
            client.close();
        };

    }

    let internationalNumberFormat = new Intl.NumberFormat('en-US');
    const changeformate = (r) => {
        let volChang = internationalNumberFormat.format(((r.q) / 1000000).toFixed(2));
        r.c = internationalNumberFormat.format(r.c);
        r.h = internationalNumberFormat.format(r.h);
        r.l = internationalNumberFormat.format(r.l);
        r.P = r.P + " %";
        r.q = volChang.toLocaleString("en", { useGrouping: false, minimumFractionDigits: 2 }) + "M";
        return r;
    }
    const changehdformate = (r) => {
        let volChang = internationalNumberFormat.format(((r.q) / 1000000).toFixed(2));
        r.h = internationalNumberFormat.format(r.h);
        r.l = internationalNumberFormat.format(r.l);
        r.P = r.P + " %";
        r.q = volChang.toLocaleString("en", { useGrouping: false, minimumFractionDigits: 2 }) + "M";
        return r;
    }
    // console.log("hello",limbyexprytime); 
    // etype=limit/market
    const buyHandler = () => {
        var data = {
            "user_id": props.userId,
            "pair": pair,
            "qty": limitqty,
            "type": etype,
            "by_price": limitPrice,
            "amount": limitTotal,
            "timeLimit":(etype==="limit")?limbyexprytime:marbyexprytime,
            "tradetype":1,
            "action": 1
        }
        console.log("bydata",data); 
        if (tWB < limitTotal) {
            Swal.fire({
                icon: 'error',
                title: `Please add fund.`,
                showCancelButton: true,
                confirmButtonText: 'Deposit Now',

            }).then((result) => {
                if (result.isConfirmed) {
                    navigate("/deposit");
                }
            });
            return;
        }
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }
        axios.post(`https://api.tradekia.com/api/bypayer`, data, config)
            .then(res => {
                console.log("res.data", res.data);
                if (res.data.status) {

                    toast.success(res.data.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    saleSideMatchHandler();
                    getUserWaletAmount();
                    // getUserpairWaletAmount(pair);
                    setlimitQty('');
                    setLimitTotal('');
                }
            }).catch(error => {
                if (error.response.status === 401) {
                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }
    const saleHandler = () => {
        var data = {
            "user_id": props.userId,
            "pair": pair,
            "qty": sLimitQty,
            "type": etype,
            "by_price": sLimitPrice,
            "amount": sTotalAmount,
            "timeLimit":(etype==="limit")?limsalexprytime:marsalexprytime,
            "tradetype":1,
            "action": 2
        }
        
        if (tWB < limitTotal) {
            Swal.fire({
                title: `Insufficient fund.<br>Please add fund.`,
                showCancelButton: true,
                confirmButtonText: 'Deposit Now',
            }).then((result) => {
                if (result.isConfirmed) {
                    navigate("/deposit");
                }
            });
            return;
        }
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }

        axios.post(`https://api.tradekia.com/api/saleUsdtPair`, data, config)
            .then(res => {
                console.log("res.data", res.data);
                if (res.data.status) {
                    buSideMatchHandler();
                    // getUserWaletAmount();
                    toast.success(res.data.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    setSLimitQty('');
                    setSTotalAmount('');
                    // window.location.reload();
                }
            }).catch(error => {
                if (error.response.status === 401) {

                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }
    const buyMarketHandler = () => {

        var data = {
            "user_id": props.userId,
            "pair": pair,
            "qty": limitqty,
            "by_price": limitPrice,
            "amount": limitTotal,
            "action": 1
        }
        if (tWB < limitTotal) {
            Swal.fire({
                icon: 'error',
                title: `Please add fund.`,
                showCancelButton: true,
                confirmButtonText: 'Deposit Now',

            }).then((result) => {
                if (result.isConfirmed) {
                    navigate("/deposit");
                }
            });
            return;
        }
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }
        axios.post(`https://api.tradekia.com/api/bypayer`, data, config)
            .then(res => {
                console.log("res.data", res.data);
                if (res.data.status) {
                    saleSideMatchHandler();
                    getUserWaletAmount();
                    toast.success(res.data.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });

                }
            }).catch(error => {
                if (error.response.status === 401) {
                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }
    const buyPridicketHandler = () => {

        var data = {
            "user_id": props.userId,
            "pair": pair,
            "qty": limitqty,
            "by_price": limitPrice,
            "amount": limitTotal,
            "action": 1
        }
        if (tWB < limitTotal) {
            Swal.fire({
                icon: 'error',
                title: `Please add fund.`,
                showCancelButton: true,
                confirmButtonText: 'Deposit Now',

            }).then((result) => {
                if (result.isConfirmed) {
                    navigate("/deposit");
                }
            });
            return;
        }
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }
        axios.post(`https://api.tradekia.com/api/bypayer`, data, config)
            .then(res => {
                if (res.data.status) {
                    saleSideMatchHandler();
                    getUserWaletAmount();
                    toast.success(res.data.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });

                }
            }).catch(error => {
                if (error.response.status === 401) {
                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }
    const salePridicketHandler = () => {
        var data = {
            "user_id": props.userId,
            "pair": pair,
            "qty": sLimitQty,
            "by_price": sLimitPrice,
            "amount": sTotalAmount,
            "action": 2
        }

        if (tWB < limitTotal) {
            Swal.fire({
                title: `Insufficient fund.<br>Please add fund.`,
                showCancelButton: true,
                confirmButtonText: 'Deposit Now',
            }).then((result) => {
                if (result.isConfirmed) {
                    navigate("/deposit");
                }
            });
            return;
        }
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }

        axios.post(`https://api.tradekia.com/api/saleUsdtPair`, data, config)
            .then(res => {
                if (res.data.status) {
                    buSideMatchHandler();
                    getUserWaletAmount();
                    toast.success(res.data.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    // window.location.reload();
                }
            }).catch(error => {
                if (error.response.status === 401) {

                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }
    const saleMarketHandler = () => {
        var data = {
            "user_id": props.userId,
            "pair": pair,
            "qty": sLimitQty,
            "by_price": sLimitPrice,
            "amount": sTotalAmount,
            "action": 2
        }

        if (tWB < limitTotal) {
            Swal.fire({
                title: `Insufficient fund.<br>Please add fund.`,
                showCancelButton: true,
                confirmButtonText: 'Deposit Now',
            }).then((result) => {
                if (result.isConfirmed) {
                    navigate("/deposit");
                }
            });
            return;
        }
        let config = {
            headers: {
                'x-access-token': props.token
            }
        }

        axios.post(`https://api.tradekia.com/api/saleUsdtPair`, data, config)
            .then(res => {
                if (res.data.status) {
                    buSideMatchHandler();
                    getUserWaletAmount();
                    toast.success(res.data.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    // window.location.reload();
                }
            }).catch(error => {
                if (error.response.status === 401) {

                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }

    const saleSideMatchHandler = () => {
        let config = {
            headers: {
                'x-access-token': props.token,
                'Content-Type': 'application/json'
            }
        }
        axios.post(`https://api.tradekia.com/api/SailSidematchExchanges`, config)
            .then(res => {
                if (res.data.status) {
                    console.log("SailSidesuccess");
                    // swal("Well Done", res.data.message, "success");
                    // window.location.reload();
                }
            }).catch(error => {
                if (error.response.status === 401) {
                    console.log("faield");
                    // refreshtokn();
                    // toast.error('Some error occured, please try again some time.', {
                    //     position: "bottom-center",
                    //     autoClose: 5000,
                    //     hideProgressBar: false,
                    //     closeOnClick: true,
                    //     pauseOnHover: true,
                    //     draggable: true,
                    //     progress: undefined,
                    // });
                }
            });
    }
    const buSideMatchHandler = () => {
        let config = {
            headers: {
                'x-access-token': props.token,
                'Content-Type': 'application/json'
            }
        }
        axios.post(`https://api.tradekia.com/api/BySidematchExchanges`, config)
            .then(res => {
                console.log("res.data123", res.data);
                if (res.data.status) {
                    console.log("bysudesuccess");
                    // swal("Well Done", res.data.message, "success");
                    // window.location.reload();
                }
            }).catch(error => {
                if (error.response.status === 401) {
                    console.log("faield");
                    // refreshtokn();
                    // toast.error('Some error occured, please try again some time.', {
                    //     position: "bottom-center",
                    //     autoClose: 5000,
                    //     hideProgressBar: false,
                    //     closeOnClick: true,
                    //     pauseOnHover: true,
                    //     draggable: true,
                    //     progress: undefined,
                    // });
                }
            });
    }

    const getUserWaletAmount = () => {
        var data = {
            "user_id": props.userId
        }
        console.log("heloo", data);
        let config = {
            headers: {
                'x-access-token': props.token,
                'Content-Type': 'application/json'
            }
        }
        axios.post(`https://api.tradekia.com/api/getTotalWaletData`, data, config)
            .then(res => {

                setTWB(res.data.walletAmount);
                // setTpSb(res.data.walletAmount);

            }).catch(error => {
                if (error.response.status === 401) {
                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }

    const getUserpairWaletAmount = (pair) => {
        var data = {
            "user_id": props.userId,
            "pair": pair
        }
        let config = {
            headers: {
                'x-access-token': props.token,
                'Content-Type': 'application/json'
            }
        }
        axios.post(`https://api.tradekia.com/api/getTotalPairWallet`, data, config)
            .then(res => {
                // console.log("resPairData", res.data);
                // setTWB(res.data.walletAmount);
                setTpSb(res.data.topamount);

            }).catch(error => {
                if (error.response.status === 401) {
                    toast.error('Some error occured, please try again some time.', {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
            });
    }
    return (
        <Box sx={{
            background: "#e0e0e0"
        }}>
            <div id="tradehead" >
                <div className={classes.container}>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className='balanceSheet_header'>
                                <div className='totalBal_div'>
                                    {/* <img src={DollarSvg} alt="totalBalance" /> BTC-USDT*/}
                                    <span>Pair</span>
                                    <div className="balDetails_div">
                                        <h4>{hd.s ? hd.s : ''}</h4>

                                    </div>
                                </div>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className="balDetails_div">
                                <span>Last Price</span>
                                <h4> {hd?.c ? hd?.c : ''}</h4>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className="balDetails_div">
                                <span>24h Change</span>
                                <h4>{hd?.p ? hd?.p : ''}(0%)</h4>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden xsDown>
                        <Paper className={classes.paper}>
                            <div className="balDetails_div">
                                <span>24h High</span>
                                <h4>{hd?.h ? hd?.h : ''}</h4>
                            </div>
                        </Paper>
                    </Hidden>
                    <Hidden smDown>
                        <Paper className={classes.paper}> <div className="balDetails_div">
                            <span>24h Low</span>
                            <h4>{hd?.l ? hd?.l : ''}</h4>
                        </div></Paper>
                    </Hidden>
                    <Hidden mdDown>
                        <Paper className={classes.paper}><div className="balDetails_div">
                            <span>Volume</span>
                            <h4>{hd?.v ? hd?.v : ''} USD </h4>
                        </div></Paper>
                    </Hidden>
                </div>
            </div>
            <div className={classes.root}>
                <div className={classes.container}>
                    <Hidden xsDown>
                        <Torders pairdata={pair} />
                    </Hidden>
                    <Hidden xsDown>
                        <Box id="chartview">
                            <Paper sx={{ width: '100%', overflow: 'hidden', padding: '0px 5px', margin: '0px 5px' }}>
                                <div id="tradingview_ea09b"></div>
                                <TradingViewWidget
                                    width="100%"
                                    height="350px"

                                    // symble={sy}     
                                    // theme={Themes.DARK}
                                    // locale="fr"
                                    // autosize

                                    //   symble={`BINANCE:${pair?.toUpperCase()}`}
                                    // symble="BINANCE:BCHUSDT"
                                    // interval="D"
                                    // timezone="Etc/UTC"
                                    // // theme="dark"
                                    // // style="1"
                                    // locale="en"
                                    // toolbar_bg="#f1f3f6"
                                    // enable_publishing="false"
                                    // allow_symbol_change="true"
                                    // container_id="tradingview_ea09b"
                                    // autosize="true"
                                    symbol={"BINANCE" + ":" + pair}
                                    // symbol="FTX:BTCPERP"
                                    interval="D"
                                    timezone="Etc/UTC"
                                    style="1"
                                    locale="en"
                                    toolbar_bg="#f1f3f6"
                                    enable_publishing="false"
                                    allow_symbol_change="false"
                                    container_id="tradingview_ea09b"
                                />
                            </Paper>
                            <Paper id="tradForm" className={classes.paper}>
                                <Box >
                                    <TabContext sx={{ bottom: '10px' }} value={value}>
                                        <Box sx={{ borderBottom: 1, height: "35px", borderColor: 'divider', bottom: '10px' }}>
                                            <TabList onChange={handleChange} aria-label="lab API tabs example">
                                                <Tab label="Limit" onClick={(e) => setEtype('limit')} value="1" />
                                                <Tab label="Market" onClick={(e) => setEtype('market')} value="2" />
                                                {/* <Tab label="TimeLImit" onClick={(e) => setEtype('timelImit')} value="3" /> */}
                                            </TabList>
                                        </Box>
                                        <TabPanel id="tabOutline" value="1">
                                            <Box sx={{ width: '100%', padding: "0px" }} >
                                                <Paper sx={{ width: '100%', padding: '0px', overflow: 'hidden' }}>
                                                    <span>Hello tab1</span>
                                                </Paper>
                                            </Box>
                                            <Box sx={{ display: 'flex', width: '100%' }}>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div>
                                                            <FormControl sx={{ bottom: '10px', width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitPrice}
                                                                    onChange={handleLimitPrice}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitqty}
                                                                    onChange={handleLimitQty}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                {/* <Box sx={{ display: 'flex' }}>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 25); }} id="outlined-weight-helper-text">25%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 50); }} id="outlined-weight-helper-text">50%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 75); }} id="outlined-weight-helper-text">75%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 100); }} id="outlined-weight-helper-text">100%</FormHelperText>
                                                                    <Switch sx={{ cursor: "pointer", left: "45px" }}
                                                                        checked={!invisiblelb}
                                                                        onChange={handleBadgeVisibilitylb}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    />
                                                                </Box> */}
                                                                <Box sx={{ width: 250, display: 'flex' }}>

                                                                    <Sliders
                                                                        value={valuepra}
                                                                        min={1}
                                                                        step={1}
                                                                        max={100}
                                                                        scale={calculateValueForPra}
                                                                        getAriaValueText={valueLabelFormatForPra}
                                                                        valueLabelFormat={valueLabelFormatForPra}
                                                                        onChange={handleChangeForPra}
                                                                        valueLabelDisplay="auto"
                                                                        aria-labelledby="non-linear-slider"
                                                                    />
                                                                    {/* <Switch sx={{ cursor: "pointer", left: "45px" }}
                                                                        checked={!invisiblelb}
                                                                        onChange={handleBadgeVisibilitylb}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    /> */}
                                                                </Box>
                                                            </FormControl>
                                                            {(invisiblelb) ?
                                                                <Box sx={{ width:"320px", paddingLeft:"10px",paddingRight:"10px",display: 'flex' }}>
                                                                    {/* <Typography id="non-linear-slider" gutterBottom>
                                                                  Storage: {valueLabelFormat(calculateValue(value))}
                                                              </Typography> */}
                                                                    <Sliders
                                                                        value={valuep}
                                                                        min={1}
                                                                        step={1}
                                                                        max={93}
                                                                        scale={calculateValue}
                                                                        getAriaValueText={valueLabelFormat}
                                                                        valueLabelFormat={valueLabelFormat}
                                                                        onChange={handleChangeLb}
                                                                        valueLabelDisplay="auto"
                                                                        aria-labelledby="non-linear-slider"
                                                                    />

                                                                </Box>
                                                                // <Slider style={{ width: '320px', position: 'relative', height: '25px' }} {...settings}>
                                                                //     <div sx={{backgroundColor:timeLimitlb==='1om'?"#1565c0":'#ede4e4 !important'}} onClick={(e) => {setTimeLimitlb('10m') }}>10M </div>
                                                                //     <div  onClick={(e) => {setTimeLimitlb('15m') }}>15M</div>
                                                                //     <div  onClick={(e) => {setTimeLimitlb('30m') }}> 30M </div>
                                                                //     <div  onClick={(e) => {setTimeLimitlb('1h') }}>1H</div>
                                                                //     <div  onClick={(e) => {setTimeLimitlb('2m') }}>2H</div>
                                                                //     <div  onClick={(e) => {setTimeLimitlb('1d') }}>1D</div>
                                                                // </Slider>
                                                                : null}
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <Box sx={{
                                                                    display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                                                                    width: "100%"
                                                                }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">Balance: {rwA !== undefined ? rwA >= 0 ? rwA : <span style={{ color: 'red' }}>Insufficient Balance</span> : tWB}</FormHelperText>
                                                                </Box>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitTotal}
                                                                    onChange={handileLimitTotal}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" onClick={buyHandler} sx={{ m: 1, width: "90%", backgroundColor: '#03675b' }} disableElevation>
                                                                BUY STORJ
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div sx={{ display: 'flex' }}>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sLimitPrice}
                                                                    onChange={handleSaleLimitPrice}
                                                                    endAdornment={<InputAdornment position="end" ><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sLimitQty}
                                                                    onChange={HandileSaleLimitQty}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"

                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ width: '250', display: 'flex' }}>
                                                                   
                                                                    <Sliders
                                                                        value={valueprasail}
                                                                        min={1}
                                                                        step={1}
                                                                        max={100}
                                                                        scale={calculateValueForPraSail}
                                                                        getAriaValueText={valueLabelFormatForPraSail}
                                                                        valueLabelFormat={valueLabelFormatForPraSail}
                                                                        onChange={handleChangeForPraSail}
                                                                        valueLabelDisplay="auto"
                                                                        aria-labelledby="non-linear-slider"
                                                                    />
                                                                    {/* <Switch sx={{ cursor: "pointer", left: "45px" }}
                                                                        checked={!invisiblels}
                                                                        onChange={handleBadgeVisibilityls}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    /> */}
                                                                </Box>
                                                            </FormControl>
                                                            {(invisiblels) ?
                                                            <Box sx={{ width:"320px", paddingLeft:"10px",display: 'flex' }}>
                                                                  
                                                                <Sliders
                                                                    value={valueLST}
                                                                    min={1}
                                                                    step={1}
                                                                    max={93}
                                                                    scale={calculateValueForLSaleTime}
                                                                    getAriaValueText={valueLabelFormatForLSaleTime}
                                                                    valueLabelFormat={valueLabelFormatForLSaleTime}
                                                                    onChange={handleChangeForlimitPraSailTime}
                                                                    valueLabelDisplay="auto"
                                                                    aria-labelledby="non-linear-slider"
                                                                />
                                                                </Box>
                                                                : null}
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <Box sx={{
                                                                    display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                                                                    width: "100%"
                                                                }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">Balance: {rswA !== undefined ? rswA >= 0 ? rswA : <span style={{ color: 'red' }}>Insufficient Balance</span> : toSb}</FormHelperText>
                                                                </Box>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sTotalAmount}
                                                                    onChange={handileSaleTotalAmount}
                                                                    // hiddenLabel={true}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total Sale',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" color="error" onClick={saleHandler} sx={{ m: 1, width: "90%" }} disableElevation>
                                                                SELL USDT
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                            </Box>

                                        </TabPanel>
                                        <TabPanel id="tabOutline" value="2">
                                            <Box sx={{ width: '100%', padding: "0px" }} >
                                                <Paper sx={{ width: '100%', padding: '0px', overflow: 'hidden' }}>
                                                    <span>Hello tab2</span>
                                                </Paper>
                                            </Box>
                                            <Box sx={{ display: 'flex', width: '100%' }}>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div>
                                                            <FormControl sx={{ bottom: '10px', width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitPrice}
                                                                    onChange={handleLimitPrice}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric",
                                                                        "disabled": "disabled"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitqty}
                                                                    onChange={handleLimitQty}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ display: 'flex' }}>
                                                                      <Sliders
                                                                        value={valuepraMar}
                                                                        min={1}
                                                                        step={1}
                                                                        max={100}
                                                                        scale={calculateValueForPraMar}
                                                                        getAriaValueText={valueLabelFormatForPraMar}
                                                                        valueLabelFormat={valueLabelFormatForPraMar}
                                                                        onChange={handleChangeForPraMar}
                                                                        valueLabelDisplay="auto"
                                                                        aria-labelledby="non-linear-slider"
                                                                    />
                                                                    {/* <Switch sx={{ cursor: "pointer", left: "45px" }}
                                                                        checked={!invisiblemb}
                                                                        onChange={handleBadgeVisibilitymb}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    /> */}
                                                                </Box>
                                                            </FormControl>
                                                            {(invisiblemb) ?
                                                                <Box sx={{ width:"320px", paddingLeft:"10px",display: 'flex' }}>
                                                                {/* <Typography id="non-linear-slider" gutterBottom>
                                                              Storage: {valueLabelFormat(calculateValue(value))}
                                                          </Typography> */}
                                                                <Sliders
                                                                    value={valuepMar}
                                                                    min={1}
                                                                    step={1}
                                                                    max={93}
                                                                    scale={calculateValueMar}
                                                                    getAriaValueText={valueLabelFormatMar}
                                                                    valueLabelFormat={valueLabelFormatMar}
                                                                    onChange={handleChangeMarb}
                                                                    valueLabelDisplay="auto"
                                                                    aria-labelledby="non-linear-slider"
                                                                />

                                                            </Box>
                                                                 : null}
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <Box sx={{
                                                                    display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                                                                    width: "100%"
                                                                }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">Balance: {rwA !== undefined ? rwA >= 0 ? rwA : <span style={{ color: 'red' }}>Insufficient Balance</span> : tWB}</FormHelperText>
                                                                </Box>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitTotal}
                                                                    onChange={handileLimitTotal}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" onClick={buyHandler} sx={{ m: 1, width: "90%", backgroundColor: '#03675b' }} disableElevation>
                                                                BUY STORJ
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div sx={{ display: 'flex' }}>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sLimitPrice}
                                                                    onChange={handleSaleLimitPrice}
                                                                    endAdornment={<InputAdornment position="end" ><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric",
                                                                        "disabled": "disabled"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>

                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sLimitQty}
                                                                    onChange={HandileSaleLimitQty}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"

                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ display: 'flex' }}>
                                                                <Sliders
                                                                        value={valueprasailMar}
                                                                        min={1}
                                                                        step={1}
                                                                        max={100}
                                                                        scale={calculateValueForPraSailMar}
                                                                        getAriaValueText={valueLabelFormatForPraSailMar}
                                                                        valueLabelFormat={valueLabelFormatForPraSailMar}
                                                                        onChange={handleChangeForPraSailMar}
                                                                        valueLabelDisplay="auto"
                                                                        aria-labelledby="non-linear-slider"
                                                                    />
                                                                    {/* <Switch sx={{ cursor: "pointer", left: "45px" }}
                                                                        checked={!invisiblems}
                                                                        onChange={handleBadgeVisibilityms}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    /> */}
                                                                </Box>
                                                            </FormControl>

                                                            {(invisiblems) ?
                                                             <Box sx={{ width:"320px", paddingLeft:"10px",display: 'flex' }}>
                                                                 <Sliders
                                                                 value={valueMarST}
                                                                 min={1}
                                                                 step={1}
                                                                 max={93}
                                                                 scale={calculateValueForMarSaleTime}
                                                                 getAriaValueText={valueLabelFormatForMarSaleTime}
                                                                 valueLabelFormat={valueLabelFormatForMarSaleTime}
                                                                 onChange={handleChangeForlimitPraSailTimeMar}
                                                                 valueLabelDisplay="auto"
                                                                 aria-labelledby="non-linear-slider"
                                                             />
                                                             </Box>
                                                                 : null}
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <Box sx={{
                                                                    display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                                                                    width: "100%"
                                                                }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">Balance: {rswA !== undefined ? rswA >= 0 ? rswA : <span style={{ color: 'red' }}>Insufficient Balance</span> : toSb}</FormHelperText>
                                                                </Box>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sTotalAmount}
                                                                    onChange={handileSaleTotalAmount}
                                                                    // hiddenLabel={true}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                            </FormControl>
                                                            <Button variant="contained" color="error" onClick={saleHandler} sx={{ m: 1, width: "90%" }} disableElevation>
                                                                SELL USDT
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                            </Box>

                                        </TabPanel>
                                        <TabPanel id="tabOutline" value="3">
                                            <Box sx={{ width: '100%', padding: "0px" }} >
                                                <Paper sx={{ width: '100%', padding: '0px', overflow: 'hidden' }}>
                                                    <span>Hello tab 3</span>
                                                </Paper>
                                            </Box>
                                            <Box sx={{ display: 'flex', width: '100%' }}>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div>
                                                            <FormControl sx={{ bottom: '10px', width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitPrice}
                                                                    onChange={handleLimitPrice}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric",
                                                                        "disabled": "disabled"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitqty}
                                                                    onChange={handleLimitQty}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ display: 'flex' }}>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 25); }} id="outlined-weight-helper-text">25%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 50); }} id="outlined-weight-helper-text">50%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 75); }} id="outlined-weight-helper-text">75%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { limtQpHandler(e, 100); }} id="outlined-weight-helper-text">100%</FormHelperText>
                                                                    <Switch
                                                                        checked={!invisible}
                                                                        onChange={handleBadgeVisibility}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    />
                                                                </Box>
                                                            </FormControl>
                                                            {(invisible) ?                                                               <Slider style={{ width: '200px', height: '25px' }} {...settings}>
                                                                    <div onClick={(e) => { setTimeLimit('10m') }}><span sx={{ cursor: "pointer", backgroundColor: 'red' }} >10M</span> </div>
                                                                    <div onClick={(e) => { setTimeLimit('15m') }}>15M</div>
                                                                    <div onClick={(e) => { setTimeLimit('30m') }}> 30M </div>
                                                                    <div onClick={(e) => { setTimeLimit('1h') }}>1H</div>
                                                                    <div onClick={(e) => { setTimeLimit('2m') }}>2H</div>
                                                                    <div onClick={(e) => { setTimeLimit('1d') }}>1D</div>
                                                                </Slider>
                                                               
                                                                : null}
                                                            {/* </Badge> */}
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <Box sx={{
                                                                    display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                                                                    width: "100%"
                                                                }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">Balance: {rwA !== undefined ? rwA >= 0 ? rwA : <span style={{ color: 'red' }}>Insufficient Balance</span> : tWB}</FormHelperText>
                                                                </Box>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={limitTotal}
                                                                    onChange={handileLimitTotal}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" onClick={buyPridicketHandler} sx={{ m: 1, width: "90%", backgroundColor: '#03675b' }} disableElevation>
                                                                BUY STORJ
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                                <Paper sx={{ width: '100%', overflow: 'hidden', padding: "5px" }}>
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        <div sx={{ display: 'flex' }}>
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Price</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sLimitPrice}
                                                                    onChange={handleSaleLimitPrice}
                                                                    endAdornment={<InputAdornment position="end" ><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'weight',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric",
                                                                        "disabled": "disabled"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            {/* type="number" pattern="[0-9]*" inputmode="numeric" */}
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <FormHelperText id="outlined-weight-helper-text">Amount</FormHelperText>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sLimitQty}
                                                                    onChange={HandileSaleLimitQty}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>STORJ</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Amount',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"

                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />
                                                                <Box sx={{ display: 'flex' }}>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { slimtQpHandler(e, 25); }} id="outlined-weight-helper-text">25%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { slimtQpHandler(e, 50); }} id="outlined-weight-helper-text">50%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { slimtQpHandler(e, 75); }} id="outlined-weight-helper-text">75%</FormHelperText>
                                                                    <FormHelperText sx={{ cursor: "pointer" }} onClick={(e) => { slimtQpHandler(e, 100); }} id="outlined-weight-helper-text">100%</FormHelperText>
                                                                    <Switch
                                                                        checked={!invisible}
                                                                        onChange={handleBadgeVisibility}
                                                                        inputProps={{ 'aria-label': 'controlled' }}
                                                                    />
                                                                </Box>
                                                            </FormControl>
                                                            {(invisible) ?
                                                                <Slider style={{ width: '200px', height: '25px' }} {...settings}>
                                                                    <div onClick={(e) => { setTimeLimit('10m') }}><span sx={{ cursor: "pointer", backgroundColor: 'red' }} >10M</span> </div>
                                                                    <div onClick={(e) => { setTimeLimit('15m') }}>15M</div>
                                                                    <div onClick={(e) => { setTimeLimit('30m') }}> 30M </div>
                                                                    <div onClick={(e) => { setTimeLimit('1h') }}>1H</div>
                                                                    <div onClick={(e) => { setTimeLimit('2m') }}>2H</div>
                                                                    <div onClick={(e) => { setTimeLimit('1d') }}>1D</div>
                                                                </Slider> :
                                                                null
                                                            }
                                                            <FormControl sx={{ width: "90%" }} variant="outlined">
                                                                <Box sx={{
                                                                    display: 'flex', flexDirection: "row", alignItems: 'center', justifyContent: "space-between",
                                                                    width: "100%"
                                                                }}>
                                                                    <FormHelperText id="outlined-weight-helper-text">Total</FormHelperText>
                                                                    <FormHelperText id="outlined-weight-helper-text">Balance: {rswA !== undefined ? rswA >= 0 ? rswA : <span style={{ color: 'red' }}>Insufficient Balance</span> : toSb}</FormHelperText>
                                                                </Box>
                                                                <OutlinedInput
                                                                    id="outlined-adornment-weight"
                                                                    value={sTotalAmount}
                                                                    onChange={handileSaleTotalAmount}
                                                                    // hiddenLabel={true}
                                                                    endAdornment={<InputAdornment position="end"><span style={{ fontSize: "0.500rem", padding: '10px' }}>USDT</span></InputAdornment>}
                                                                    aria-describedby="outlined-weight-helper-text"
                                                                    inputProps={{
                                                                        'aria-label': 'Total',
                                                                        'type': 'number',
                                                                        'pattern': "[0-9]*",
                                                                        'inputmode': "numeric"
                                                                    }}
                                                                    sx={{ height: "30px", borderRadius: "10px", paddingRight: '0px', lineHeight: "0.4375em", fontSize: "0.8856rem" }}
                                                                />

                                                            </FormControl>
                                                            <Button variant="contained" color="error" onClick={salePridicketHandler} sx={{ m: 1, width: "90%" }} disableElevation>
                                                                SELL USDT
                                                            </Button>
                                                        </div>
                                                    </Box>
                                                </Paper>
                                            </Box>

                                        </TabPanel>
                                    </TabContext>
                                </Box>
                            </Paper>
                        </Box>
                    </Hidden>
                    <Hidden xsDown>
                        <Hidden >
                            <Box>
                                <Tpairs pairdata={(p) => setPair(p)} />
                                <Thistory pairdata={pair} />
                            </Box>
                        </Hidden>
                    </Hidden>
                </div>
            </div>
            <ToastContainer
                position="bottom-center"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl
                pauseOnFocusLoss
                draggable
                pauseOnHover
            />
        </Box>
    );
}

TradChart.propTypes = {
    width: PropTypes.oneOf(['lg', 'md', 'sm', 'xl', 'xs']).isRequired,
};
const mapStateToProps = (state) => {
    return ({
        token: state.token,
        rftokn: state.rfTOken,
        id: state.id,
        userId: state.user_id,
        ip: state.ip,
        did: state.deviceId,
        email: state.email,
    })
}

export default connect(mapStateToProps)(TradChart);

